package co.edu.uniquindio.poo;

import java.util.List;
//Single Responsability//
public class NotaMateria {
        public static double calcularDefinitiva(List<Double> notas){
        double suma = notas.stream().mapToDouble(Double::doubleValue).sum();
        return suma / notas.size();
        }
}
