package co.edu.uniquindio.poo;
//Liskov Substitution Principle//

public class Bicicleta extends Vehiculo {

    public Bicicleta(double velocidad){
        super(velocidad);
    }


    @Override
    public double calcularVelocidad() {
        return getVelocidad();
    }
}