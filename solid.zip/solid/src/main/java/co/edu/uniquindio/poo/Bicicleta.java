package co.edu.uniquindio.poo;
//Liskov Substitution Principle//

public class Bicicleta implements Vehiculo {
    private double velocidad;

    public Bicicleta(double velocidad) {
        this.velocidad = velocidad;
    }

    public double getVelocidad() {
        return velocidad;
    }

    @Override
    public double calcularVelocidad() {
        return velocidad;
    }
}