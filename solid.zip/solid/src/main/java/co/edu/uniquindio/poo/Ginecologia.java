package co.edu.uniquindio.poo;
//Interface Segrgation//
public interface Ginecologia {

    public void servicioGinecologia();
} 
