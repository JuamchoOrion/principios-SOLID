package co.edu.uniquindio.poo;
//Interface Segregation//
public interface Urologia {
    
    public void servicioUrologia();
}
