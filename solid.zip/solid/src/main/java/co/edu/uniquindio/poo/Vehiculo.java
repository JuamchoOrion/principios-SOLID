package co.edu.uniquindio.poo;
//Liskov Substitution Principle//
public abstract class Vehiculo {
    private double velocidad;
    public Vehiculo(double velocidad){
        this.velocidad = velocidad;
    }
    
    public abstract double calcularVelocidad();

    public double getVelocidad() {
        return velocidad;
    }
}
