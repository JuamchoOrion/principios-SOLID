package co.edu.uniquindio.poo;
//Liskov Substitution Principle//
public interface Vehiculo {
    double calcularVelocidad();
}
