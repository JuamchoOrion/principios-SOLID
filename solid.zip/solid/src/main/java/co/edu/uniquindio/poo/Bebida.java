package co.edu.uniquindio.poo;
//Open/closed Principle
public class Bebida extends Producto{
    public Bebida(double precio, String codigo, String nombre) {
        super(precio, codigo, nombre);
    }
    @Override
    public double calcularPrecio(){
        return super.getPrecio();
    }
}
