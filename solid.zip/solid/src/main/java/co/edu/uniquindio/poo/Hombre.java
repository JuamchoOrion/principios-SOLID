package co.edu.uniquindio.poo;
//Interface Segrgation//
public class Hombre implements Urologia{
        private String nombre;

    public Hombre (String nombre){
        this.nombre=nombre;
    }

    public String getNombre(){
        return nombre;
    }

  @Override
  public void servicioUrologia(){
    
  }

}

