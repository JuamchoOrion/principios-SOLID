package co.edu.uniquindio.poo;
//Liskov Substitution Principle//
public class Main {
    public static void main(String[] args) {
        Vehiculo automovil = new Automovil(120.0);
        Vehiculo bicicleta = new Bicicleta(20.0);

        System.out.println("Velocidad del automóvil: " + automovil.calcularVelocidad() + " km/h");
        System.out.println("Velocidad de la bicicleta: " + bicicleta.calcularVelocidad() + " km/h");
    }
}
