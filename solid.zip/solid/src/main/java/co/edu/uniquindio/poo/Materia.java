package co.edu.uniquindio.poo;

import java.util.List;
//Principio SOLID //
//S -> Single responsability//
public class Materia {
    private List<Double> notas;
    private String nombre;
    private String codigo;
    private double definitiva;

    public Materia(List<Double> notas, String nombre, String codigo) {
        this.notas = notas;
        this.nombre = nombre;
        this.codigo = codigo;
    }
    //Calcular nota final //
    public void calcularDefinitiva(List<Double> notas){
        double resultado = 0;//Aca va la logica//
        setDefinitiva(resultado);
    }
    //getters//
    public List<Double> getNotas() {
        return notas;
    }
    public String getNombre() {
        return nombre;
    }
    public String getCodigo() {
        return codigo;
    }
    public double getDefinitiva() {
        return definitiva;
    }
    //Setters//
    public void setNotas(List<Double> notas) {
        this.notas = notas;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public void setDefinitiva(double definitiva) {
        this.definitiva = definitiva;
    }
}
