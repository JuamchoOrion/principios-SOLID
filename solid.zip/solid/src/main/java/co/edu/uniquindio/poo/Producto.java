package co.edu.uniquindio.poo;
// open/closed Principle

public abstract class Producto implements CalcularPrecio{
    private double precio;
    private String codigo;
    private String nombre;
    
    public Producto(double precio, String codigo, String nombre) {
        this.precio = precio;
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    @Override

    public double calcularPrecio(){
    return 0;
    }
}
