package co.edu.uniquindio.poo;
//principio open/closed
public interface CalcularPrecio {

    public double calcularPrecio();
} 
