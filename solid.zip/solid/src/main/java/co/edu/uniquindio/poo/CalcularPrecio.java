package co.edu.uniquindio.poo;
//open/Closed Principle
public interface CalcularPrecio {

    public double calcularPrecio();
} 
