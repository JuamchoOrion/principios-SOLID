package co.edu.uniquindio.poo;
//principio open/closed

public class Comida extends Producto{
    public Comida(double precio, String codigo, String nombre) {
        super(precio, codigo, nombre);
    }

}
