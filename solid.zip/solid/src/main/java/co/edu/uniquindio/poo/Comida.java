package co.edu.uniquindio.poo;
//Open / Closed Principle

public class Comida extends Producto{
    public Comida(double precio, String codigo, String nombre) {
        super(precio, codigo, nombre);
    }

}
