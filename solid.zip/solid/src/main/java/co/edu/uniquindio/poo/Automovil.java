package co.edu.uniquindio.poo;
//Liskov Substitution Principle//
public class Automovil implements Vehiculo{
    private double velocidad;

    public Automovil(double velocidad) {
        this.velocidad = velocidad;
    }

    public double getVelocidad() {
        return velocidad;
    }

    @Override
    public double calcularVelocidad() {
        return velocidad;
    }
}
