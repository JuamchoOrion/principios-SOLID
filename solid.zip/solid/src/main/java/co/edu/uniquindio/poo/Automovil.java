package co.edu.uniquindio.poo;
//Liskov Substitution Principle//
public class Automovil extends Vehiculo{

    public Automovil(double velocidad){
        super(velocidad);
    }


    @Override
    public double calcularVelocidad() {
        return getVelocidad();
    }
}
