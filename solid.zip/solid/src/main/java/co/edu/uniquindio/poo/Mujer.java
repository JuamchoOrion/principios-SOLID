package co.edu.uniquindio.poo;
//Interface Segrgation//
public class Mujer {
    private String nombre;

    public Mujer(String nombre){
        this.nombre=nombre;
    }

    
}
