package co.edu.uniquindio.poo;
//Interface Segrgation//
public class Mujer implements Ginecologia{
    private String nombre;

    public Mujer(String nombre){
        this.nombre=nombre;
    }

    public String getNombre(){
        return nombre;
    }

    @Override
    public void servicioGinecologia(){

    };
}
